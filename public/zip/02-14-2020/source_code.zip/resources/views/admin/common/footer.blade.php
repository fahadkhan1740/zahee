<footer class="main-footer" style="padding-bottom:35px">
  <div class="col-xs-12 text-right" > </div>
</footer>
